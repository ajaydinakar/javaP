package com.aj_bank.banker.bean;

public class BankerBean {

}
